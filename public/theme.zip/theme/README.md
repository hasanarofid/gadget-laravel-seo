# Preview
> Link - https://adiyadav123.github.io/Apple-Website-Clone/
<br> 

> Home Page
<img src="./assets/readme/first_page.png" width="auto" height="auto">

> iPhone 14 Pro Page

<img src="./assets/readme/second_page.png" width="auto" height="auto">

> iPhone 14 Page

<img src="./assets/readme/third_page.png" width="auto" height="auto">

> Easy To Switch Page

<img src="./assets/readme/fourth_page.png" width="auto" height="auto">

> Apple Watch & iPad Page

<img src="./assets/readme/fifth_page.png" width="auto" height="auto">

> AirPods & Trade Page

<img src="./assets/readme/sixth_page.png" width="auto" height="auto">

> Thank you 🍪
